module RingBuffer

open Mini
open RingBufferTypes

// a)
let create<'T> (capacity: Int): RingBuffer<'T> =
    failwith "TODO"

// b)
let get<'T> (r: RingBuffer<'T>): 'T option =
    failwith "TODO"

// c)
let put<'T> (r: RingBuffer<'T>) (elem: 'T): unit =
    failwith "TODO"
