module Shapes
open Mini
open ShapesTypes

// a)
let square (size: Nat): IShape =
    failwith "TODO"

// b)
let rectangle (width: Nat, height: Nat): IShape =
    failwith "TODO"

// c)
let union (s1: IShape, s2: IShape): IShape =
    failwith "TODO"

// d)
let move (deltaX: Nat, deltaY: Nat) (s: IShape): IShape =
    failwith "TODO"
