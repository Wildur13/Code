module Queues 

open Mini
open QueuesTypes


// Der auf dem Übungsblatt abgebildete Baum zum Testen
let ex = Node (Node(Node(Empty,1N,Empty),2N,Node(Empty,3N,Empty)) , 4N, Node(Node(Empty,5N,Empty),6N,Node(Empty,7N,Empty)))


// a)
let simpleQueue<'T> (): IQueue<'T> =
    failwith "TODO"

// b)
let advancedQueue<'T> (): IQueue<'T> =
    failwith "TODO"

// c)
let rec enqueue (q: IQueue<'T>) (elems: 'T list): Unit =
    failwith "TODO"

let rec dequeue (q: IQueue<'T>): 'T list =
    failwith "TODO"

// d)
let rec bft (q: IQueue<Tree<'T>>): 'T list  =
    failwith "TODO"
