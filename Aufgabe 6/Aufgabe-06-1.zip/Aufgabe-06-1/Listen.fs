module Listen
open Mini

// a)
let rec append<'a> (xs: 'a list) (ys: 'a list): 'a list =
    failwith "TODO"

// b)
let rec concat<'a> (xss: 'a list list): 'a list =
    failwith "TODO"

// c)
let rec map<'a, 'b> (f: 'a -> 'b) (xs: 'a list): 'b list =
    failwith "TODO"

// d)
let rec filter<'a> (pred: 'a -> bool) (xs: 'a list): 'a list =
    failwith "TODO"

// e)
let rec collect<'a, 'b> (f: 'a -> 'b list) (xs: 'a list): 'b list =
    failwith "TODO"
