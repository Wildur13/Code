module Heaps
open Mini
open HeapType

// Beispiele vom Übungsblatt (zur Verwendung im Interpreter):
let ex1 = Node(2N, Node(6N,Empty,Empty), Node(4N,Empty,Empty))
let ex2 = Node(3N, Node(7N,Empty,Empty), Node(5N,Empty,Empty))
let ex3 = Node(1N, Node(1N,Empty,Empty), Empty)
let inv1 = Node(3N, Node(2N,Empty,Empty), Empty)
let inv2 = Node(3N, Node(5N, Node(4N,Empty,Empty), Empty), Empty)


// a)
let rec size<'T> (root: Heap<'T>): Nat =
    failwith "TODO"

let rec height<'T> (root: Heap<'T>): Nat =
    failwith "TODO"

// b)
let rec isHeap<'T when 'T: comparison> (root: Heap<'T>): bool =
    failwith "TODO"

// c)
let head<'T > (root: Heap<'T>): 'T =
    failwith "TODO"

// d)
let rec merge<'T when 'T: comparison> (root1: Heap<'T>) (root2: Heap<'T>): Heap<'T> =
    failwith "TODO"

// e)
let tail<'T when 'T: comparison> (root: Heap<'T>): Heap<'T> =
    failwith "TODO"

// f)
let insert<'T when 'T: comparison> (root: Heap<'T>) (x: 'T): Heap<'T> =
    failwith "TODO"

// g)
let rec ofList<'T when 'T: comparison> (xs: 'T list): Heap<'T> =
    failwith "TODO"

let rec toList<'T when 'T: comparison> (root: Heap<'T>): 'T list =
    failwith "TODO"

// h)
let heapsort<'T when 'T: comparison> (xs: 'T list): 'T list =
    failwith "TODO"
