module Bib

open Mini
open BibTypes
open BibExceptions

// a)
let rec listFind<'T> (predicate: 'T -> Bool) (xs: 'T list): 'T =
    failwith "TODO"

// b)
let findeBuch (bib: Buch list) (titel: String): Buch =
    failwith "TODO"

// c)
let rec leiheBuch (bib: Buch list) (titel: String) (person: String): unit =
    failwith "TODO"

// d)
let rec rueckgabe (bib: Buch list) (titel: String) (person: String): unit =
    failwith "TODO"
