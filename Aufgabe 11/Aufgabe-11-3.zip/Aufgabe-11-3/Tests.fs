module Tests

open Microsoft.VisualStudio.TestTools.UnitTesting
open Microsoft.FSharp.Reflection
open System.Text.RegularExpressions
open FsCheck
open Mini
open BibTypes


[<StructuredFormatDisplay("{s}")>]
type SafeString = SS of s: string

type SafeBuch = SB of sb: Buch


let sample(): Buch list = 
    let bib = [
          {titel="Algorithms"; exemplare=[ref Verfuegbar; ref (Dauerleihe "AG Softwaretechnik")]; warteliste=ref []}
        ; {titel="Grundlagen der Programmierung"; exemplare=[ref Verfuegbar; ref Verfuegbar]; warteliste=ref []}
        ; {titel="F# for Beginners"; exemplare=[ref (Dauerleihe "AG Softwaretechnik"); ref (Dauerleihe "AG Softwaretechnik")]; warteliste=ref []}
        ; {titel="F# for Experts"; exemplare=[ref (Dauerleihe "AG Softwaretechnik"); ref (NormaleLeihe "Lisa Lista"); ref Verfuegbar]; warteliste=ref []}
        ; {titel="Introduction to Python"; exemplare=[ref Verfuegbar; ref (NormaleLeihe "Harry Hacker")]; warteliste=ref []}
        ]
    bib

type ArbitraryModifiers =
    static member Nat() =
        Arb.from<bigint>
        |> Arb.filter (fun i -> i >= 0I)
        |> Arb.convert (Nat.Make) (fun n -> n.ToBigInteger())

    static member SafeString() =
        Arb.from<string>
        |> Arb.filter (not << isNull)
        |> Arb.convert (String.filter (fun c -> (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) (id)
        |> Arb.convert (SS) (fun (SS s) -> s)

    static member SafeBuch() =
        Arb.from<Buch>
        |> Arb.filter (fun b -> not (isNull b.titel))
        |> Arb.filter (fun b -> String.length b.titel > 3)
        |> Arb.convert (fun x -> {titel=(String.filter (fun c -> (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) x.titel); exemplare=x.exemplare; warteliste=x.warteliste}) (id)
        |> Arb.convert (SB) (fun (SB sb) -> sb)


let expectException (name: string) (f: unit -> unit): unit =
    try
        f()
        Assert.Fail (sprintf "Es wurde keine %s Ausnahme ausgelöst!" name)
    with
    | :? AssertFailedException -> reraise()
    | e ->
        let eType = e.GetType()
        if eType.FullName <> "BibExceptions+"+name then
            if eType.FullName.StartsWith "BibExceptions+" then
                Assert.AreEqual(name, eType.Name, "Es wurde eine falsche Ausnahme ausgelöst!")
            else failwithf "Es wurde eine %s ausgelöst statt einer eigenen %s Ausname!" eType.FullName name

let expectExceptionWithArgument (name: string, arg: string) (f: unit -> unit): unit =
    try
        f()
        Assert.Fail (sprintf "Es wurde keine %s Ausnahme ausgelöst!" name)
    with
    | :? AssertFailedException -> reraise()
    | e ->
        let exarg = (FSharpValue.GetExceptionFields(e).[0]).ToString()
        let eType = e.GetType()
        if eType.FullName <> "BibExceptions+"+name then
            if eType.FullName.StartsWith "BibExceptions+" then
                Assert.AreEqual(name, eType.Name, "Es wurde eine falsche Ausnahme ausgelöst!")
                Assert.AreEqual(arg, exarg, "Argument der Exception nicht korrekt.")
            else failwithf "Es wurde eine %s ausgelöst statt einer eigenen %s Ausname!" eType.FullName name
        else
            Assert.AreEqual(arg, exarg, "Argument der Ausnahme nicht korrekt.")


[<TestClass>]
type Tests() =
    do Arb.register<ArbitraryModifiers>() |> ignore

    // ------------------------------------------------------------------------
    // a)

    [<TestMethod>] [<Timeout(1000)>]
    member this.``a) Beispiel 1`` (): unit =
        Assert.AreEqual(9, Bib.listFind (fun x -> x > 8) [1..10], "Es wurde nicht das richtige Element gefunden.")

    [<TestMethod>] [<Timeout(1000)>]
    member this.``a) Beispiel 2`` (): unit =
        expectException "NichtGefunden" (fun () -> Bib.listFind (fun x -> x > 10) [1..10] |> ignore)

    member this.``a) Zufall`` (): unit =
        Check.One({Config.QuickThrowOnFailure with MaxTest = 1000}, fun ( pred: Int -> Bool,  xs: Int list ) ->
            if List.exists pred xs then
                let actual = Bib.listFind pred xs
                Assert.IsTrue(List.contains actual xs, "Zurückgegebenes Element ist nicht in der Liste")
                Assert.IsTrue(pred actual, "Zurückgegebenes Element erfüllt pred nicht");
            else
                expectException "NichtGefunden" (fun () -> Bib.listFind pred xs |> ignore)
        )


    // ------------------------------------------------------------------------
    // b)

    [<TestMethod>] [<Timeout(1000)>]
    member this.``b) Beispiel 1. Buch nicht vorhanden`` (): unit =
        let bib = sample()
        expectExceptionWithArgument ("BuchUnbekannt", "Python") (fun () -> Bib.findeBuch bib "Python" |> ignore)

    [<TestMethod>] [<Timeout(10000)>]
    member this.``b) Zufall: 1. Buch nicht vorhanden`` (): unit =
        Check.One({Config.QuickThrowOnFailure with EndSize = 100}, fun (rb: SafeBuch list) ->
            let rb = List.map (fun (SB sb) -> sb) rb
            expectExceptionWithArgument ("BuchUnbekannt","123") (fun () ->  Bib.findeBuch rb "123" |> ignore) // (da nach def. oben keine Zahlen in Titel erlaubt)
        )

    [<TestMethod>] [<Timeout(1000)>]
    member this.``b) Beispiel: 2. Exemplar verfügbar`` (): unit =
        let mkbuch = fun() -> {titel="Algorithms"; exemplare=[]; warteliste=ref []}
        let bib = [mkbuch()]
        Assert.AreEqual(mkbuch(), Bib.findeBuch bib "Algorithms")

    [<TestMethod>] [<Timeout(10000)>]
    member this.``b) Zufall: 2. Exemplar verfügbar`` (): unit =
        Check.One({Config.QuickThrowOnFailure with EndSize = 100}, fun (rb: SafeBuch list) ->
            let rb = List.map (fun (SB sb) -> sb) rb
            if rb.Length > 0 then
                //let rnd = System.Random()
                //let buch = List.nth rb (rnd.Next(rb.Length))
                let buch = List.head rb
                Assert.AreEqual(buch, Bib.findeBuch rb buch.titel)
        )


    // ------------------------------------------------------------------------
    // c)

    [<TestMethod>] [<Timeout(1000)>]
    member this.``c) Beispiel: 1. Buch nicht vorhanden`` (): unit =
        let bib = sample()
        expectExceptionWithArgument ("BuchUnbekannt", "Python") (fun () -> Bib.leiheBuch bib "Python" "Harry Hacker")
        Assert.AreEqual(sample(), bib, "Zustand der Bibliothek wurde verändert, obwohl das Buch nicht auf der Liste der Bibliothek steht.")
    

    [<TestMethod>] [<Timeout(10000)>]
    member this.``c) Zufall: 1. Buch nicht vorhanden`` (): unit =
        Check.One({Config.QuickThrowOnFailure with EndSize = 100}, fun (rb: SafeBuch list) ->
            let rb = List.map (fun (SB sb) -> sb) rb
            expectExceptionWithArgument ("BuchUnbekannt","123") (fun () ->  Bib.leiheBuch rb "123" "Harry Hacker") // (da nach def. oben keine Zahlen in Titel erlaubt)
        )


    [<TestMethod>] [<Timeout(1000)>]
    member this.``c) Beispiel: 2. Exemplar verfügbar`` (): unit =
        let p1 = "Bob"
        let p2 = "Eve"
        let p3 = "Alice"
        let v1 = ref Verfuegbar
        let ws = ref []
        let mkbuch = fun() -> {titel="Algorithms"; exemplare=[ref (Dauerleihe "AG Softwaretechnik"); ref (NormaleLeihe "Lisa Lista"); v1]; warteliste=ws}
        let bib = [mkbuch()]

        Assert.AreEqual((), Bib.leiheBuch bib "Algorithms" p1)
        Assert.AreEqual(NormaleLeihe p1, !v1, "Statusänderung des Exemplars nach NormaleLeihe Bob war nicht erfolgreich.")


    [<TestMethod>] [<Timeout(1000)>]
    member this.``c) Beispiel: 3. Alle Exemplare in Dauerleihe`` (): unit =
        let bib = sample()
        expectException "NichtVerfuegbar" (fun () -> Bib.leiheBuch bib "F# for Beginners" "Eve")
        Assert.AreEqual(sample(), bib, "Zustand wurde verändert, obwohl kein Exemplar verfügbar.")


    [<TestMethod>] [<Timeout(1000)>]
    member this.``c) Beispiel: 4. Warteliste`` (): unit =
        let p1 = "Bob"
        let p2 = "Eve"
        let p3 = "Alice"
        let v1 = ref (NormaleLeihe p1)
        let ws = ref []
        let buch = {titel="F# for Experts"; exemplare=[ref (Dauerleihe "AG Softwaretechnik"); ref (NormaleLeihe "Lisa Lista"); v1]; warteliste=ws}
        let bib = [buch]

        // Warteliste: Eintrag 1
        expectException "Warteliste" (fun () -> Bib.leiheBuch bib "F# for Experts" p2)
        Assert.AreEqual([p2], !buch.warteliste)

        // Warteliste: Eintrag 2
        expectException "Warteliste" (fun () -> Bib.leiheBuch bib "F# for Experts" p3)
        Assert.AreEqual([p2;p3], !buch.warteliste, "Warteliste hat nicht die richtige Reihenfolge.")

    // ------------------------------------------------------------------------
    // d)

    [<TestMethod>] [<Timeout(1000)>]
    member this.``d) Beispiel: 1. Rückgabe nicht möglich wenn ein Buch nicht in der Bibliothek gelistet ist`` (): unit =
        let bib = sample()
        expectExceptionWithArgument ("BuchUnbekannt","Python") (fun () -> Bib.rueckgabe bib "Python" "Harry Hacker")
        Assert.AreEqual(sample(), bib, "Zustand wurde verändert, obwohl kein Exemplar zurückgegeben wurde.")

    [<TestMethod>] [<Timeout(10000)>]
    member this.``d) Zufall: 1. Rückgabe nicht möglich wenn ein Buch nicht in der Bibliothek gelistet ist`` (): unit =
        Check.One({Config.QuickThrowOnFailure with EndSize = 100}, fun (rb: SafeBuch list) ->
            let rb = List.map (fun (SB sb) -> sb) rb
            expectExceptionWithArgument ("BuchUnbekannt","123") (fun () -> Bib.rueckgabe rb "123" "Harry Hacker") // (da nach def. oben keine Zahlen in Titel erlaubt)
        )


    [<TestMethod>] [<Timeout(1000)>]
    member this.``d) Beispiel: 2. Rückgabe ohne Warteliste`` (): unit =
        let v1 = ref (NormaleLeihe "Lisa Lista")
        let ws = ref []
        let mkbuch = fun() -> {titel="F# for Experts"; exemplare=[ref (Dauerleihe "AG Softwaretechnik"); v1; ref Verfuegbar]; warteliste=ws}
        let buch = mkbuch()
        let bib = [buch]

        Assert.AreEqual((), Bib.rueckgabe bib "F# for Experts" "Lisa Lista")
        Assert.AreEqual(Verfuegbar, !v1, "Exemplar ist nicht in den Status Verfuegbar gewechselt.")
        Assert.AreEqual([mkbuch()], bib, "Es hat sich mehr am Zustand verändert, als nur die Rückgabe des Buches.")


    [<TestMethod>] [<Timeout(1000)>]
    member this.``d) Beispiel: 3. Rückgabe mit Warteliste`` (): unit =
        let v1 = ref (NormaleLeihe "Lisa Lista")
        let v2 = ref (NormaleLeihe "Harry Hacker")
        let ws = ref ["Alice"; "Bob"]
        let mkbuch = fun() -> {titel="F# for Experts"; exemplare=[ref (Dauerleihe "AG Softwaretechnik"); v1; v2]; warteliste=ws}
        let buch = mkbuch()
        let bib = [buch]

        Assert.AreEqual((), Bib.rueckgabe bib "F# for Experts" "Lisa Lista")
        Assert.AreEqual(NormaleLeihe "Alice", !v1, "Das Buch wurde nach der Rückgabe nicht an die erste Person auf der Warteliste weiterverliehen.")
        Assert.AreEqual(["Bob"], !ws, "Die Warteliste ist nach dem Weiterverleihen nicht korrekt.")


    [<TestMethod>] [<Timeout(1000)>]
    member this.``d) Beispiel: 4. Rückgabe nicht möglich wenn kein Exemplar an Person verliehen`` (): unit =
        let bib = sample()
        expectExceptionWithArgument ("KeinExpemlarVerliehenAn","Alice") (fun () -> Bib.rueckgabe bib "F# for Experts" "Alice")
        Assert.AreEqual(sample(), bib, "Zustand wurde verändert, obwohl kein Exemplar zurückgegeben wurde.")
