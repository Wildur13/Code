module BibA10

open Mini
open BibTypes

let rec leiheBuch (bib: Buch list) (titel: String) (person: String): AusleihenErgebnis option =
    let rec pruefeVerfuegbarkeit (exemplare: Ausleihstatus ref list): AusleihenErgebnis =
        match exemplare with
        | [] -> NichtVerfuegbar
        | e::es ->
            match !e with
            | Verfuegbar ->
                e := NormaleLeihe person
                ErfolgreichAusgeliehen
            | Dauerleihe _ -> pruefeVerfuegbarkeit es
            | NormaleLeihe _ ->
                if pruefeVerfuegbarkeit es = ErfolgreichAusgeliehen
                then ErfolgreichAusgeliehen
                else Warteliste

    match List.tryFind (fun (buch: Buch) -> buch.titel = titel) bib with
    | None -> None // Buch nicht vorhanden
    | Some buch ->
        let v = pruefeVerfuegbarkeit buch.exemplare
        if v = Warteliste then buch.warteliste := !buch.warteliste @ [person]
        Some v

let rec rueckgabe (bib: Buch list) (titel: String) (person: String): bool =
    match List.tryFind (fun (buch: Buch) -> buch.titel = titel) bib with
    | None -> false // Buch nicht vorhanden
    | Some buch ->  // Status ändern + ausleihen, falls Warteliste befüllt
        List.exists (fun e -> 
            if !e = NormaleLeihe person then // Buch zurückgegeben
                e := Verfuegbar
                // Entferne ersten Eintrag von Warteliste und rufe leiheBuch auf
                match !buch.warteliste with
                | [] -> true // niemand auf Warteliste
                | p::ps -> buch.warteliste := ps
                           leiheBuch bib titel p |> ignore; true                
            else false
            ) buch.exemplare
