module BibExceptions

open Mini

exception NichtGefunden
exception BuchUnbekannt of String  // Buch nicht in Bibliothek vorhanden

exception Warteliste      // Person auf die Warteliste gesetzt
exception NichtVerfuegbar // Alle Exemplare in Dauerleihe, daher keine Warteliste

exception KeinExpemlarVerliehenAn of String // Kein Exemplar an Person geliehen