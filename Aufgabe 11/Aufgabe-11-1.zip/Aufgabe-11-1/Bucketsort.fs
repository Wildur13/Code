module Bucketsort

open Mini

let bucketsort<'T> (elems: (Int * 'T) list) (upper: Int) (n: Int): (Int * 'T) list =
    failwith "TODO"
